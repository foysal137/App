# Jarvis Lite — Gemini Live Voice AI Assistant

বাংলায় কথা বলুন, Gemini-র সাথে রিয়েল-টাইম ভয়েস AI অ্যাসিস্ট্যান্ট।

---

## 🚀 Android Studio-তে খোলার পদ্ধতি

1. **ক্লোন করুন বা ডাউনলোড করুন** — এই `jarvis-lite/` ফোল্ডারটা Android Studio-তে খুলুন
2. **Gradle sync করুন** — Android Studio স্বয়ংক্রিয়ভাবে sync করবে
3. **API Key সেট করুন** — অ্যাপ চালু করার পর Settings → API Key-এ আপনার Gemini API key দিন
4. **Build & Run** — একটা Android 8.1+ ডিভাইস বা emulator-এ রান করুন

---

## 📋 প্রথমবার সেটআপ চেকলিস্ট

### ১. Gemini API Key (অবশ্যই)
- [ai.google.dev](https://ai.google.dev) → "Get API Key" → বিনামূল্যে key নিন
- অ্যাপের Settings স্ক্রিনে পেস্ট করুন
- Key EncryptedSharedPreferences-এ সেভ থাকে — plain text নয়

### ২. Wake Word সেটআপ (ঐচ্ছিক)
Wake word (যেমন "Hey Jarvis") সাপোর্টের জন্য:
1. [Picovoice Console](https://console.picovoice.ai/) → বিনামূল্যে অ্যাকাউন্ট করুন
2. "Wake Word" → Custom keyword তৈরি করুন ("Hey Jarvis" বা যেকোনো শব্দ)
3. Android `.ppn` ফাইল ডাউনলোড করুন
4. ফাইলটা রাখুন: `app/src/main/assets/wake_word.ppn`
5. Settings → Wake Word → চালু করুন

> ⚠️ Porcupine Access Key আলাদা — `WakeWordDetector.kt`-এ `accessKey` প্যারামিটারে দিন
> অথবা Settings-এ একটা আলাদা ফিল্ড তৈরি করুন।
> **এখনকার বাস্তবায়নে Wake Word disabled থাকলে অ্যাপ স্বাভাবিকভাবে চলে।**

### ৩. Voice Lock (ঐচ্ছিক)
- Settings → Voice Lock চালু করুন
- Passphrase লিখুন (যেমন: "আমি সূর্য আমার দরজা খোলো")
- এরপর wake word শুনার পর অ্যাপ এই passphrase চাইবে

---

## 🏗️ প্রজেক্ট স্ট্রাকচার

```
app/src/main/kotlin/com/jarvis/lite/
├── MainActivity.kt          — entry point, permission gate
├── JarvisApp.kt             — Application class
├── ui/
│   ├── NavGraph.kt          — navigation
│   ├── PermissionScreen.kt  — mic permission request UI
│   ├── chat/
│   │   ├── ChatScreen.kt    — মেইন ভয়েস স্ক্রিন (animated mic, bubbles)
│   │   └── ChatViewModel.kt — service bind, tool call dispatch, DB save
│   ├── settings/
│   │   ├── SettingsScreen.kt  — API key, prompt, voice, wake word, lock
│   │   └── SettingsViewModel.kt
│   └── history/
│       ├── HistoryScreen.kt   — পুরনো সেশন দেখা
│       └── HistoryViewModel.kt
├── data/
│   ├── local/               — Room DB (ChatSession, ChatMessage, SavedProfile)
│   └── prefs/               — EncryptedSharedPreferences wrapper
├── audio/
│   ├── AudioRecorder.kt     — AudioRecord 16kHz PCM capture
│   └── AudioPlayer.kt       — AudioTrack 24kHz streaming playback
├── network/
│   ├── GeminiLiveClient.kt  — OkHttp WebSocket, bidirectional streaming
│   └── GeminiModels.kt      — request/response data classes, tool declarations
├── wakeword/
│   └── WakeWordDetector.kt  — Picovoice Porcupine wrapper
├── security/
│   └── PassphraseVerifier.kt — STT text fuzzy matching
├── actions/
│   ├── AppLauncher.kt       — open_app via PackageManager
│   ├── MusicController.kt   — play/pause/stop/next/prev via MediaStore+MediaPlayer
│   └── VolumeController.kt  — set/increase/decrease/mute via AudioManager
└── service/
    ├── VoiceSessionService.kt — Foreground Service, wake word + Gemini lifecycle
    └── BootReceiver.kt        — auto-restart on device boot
```

---

## ✨ ফিচার সারসংক্ষেপ

| ফিচার | অবস্থা |
|-------|--------|
| Gemini Live WebSocket voice chat | ✅ সম্পূর্ণ |
| 16kHz mic → 24kHz speaker streaming | ✅ সম্পূর্ণ |
| Echo cancellation (AcousticEchoCanceler) | ✅ সম্পূর্ণ (device support হলে) |
| Live transcript chat bubbles | ✅ সম্পূর্ণ |
| Dark theme + animated mic | ✅ সম্পূর্ণ |
| Settings (API key, prompt, voice, language) | ✅ সম্পূর্ণ |
| EncryptedSharedPreferences | ✅ সম্পূর্ণ |
| Voice selection (Puck/Charon/Kore/Fenrir/Aoede/...) | ✅ সম্পূর্ণ |
| Saved profiles / presets | ✅ সম্পূর্ণ |
| Chat history (Room DB) | ✅ সম্পূর্ণ |
| Foreground Service | ✅ সম্পূর্ণ |
| Boot auto-restart | ✅ সম্পূর্ণ |
| Wake word (Porcupine) | ✅ কোড সম্পূর্ণ, .ppn ফাইল দরকার |
| Voice lock (passphrase) | ✅ সম্পূর্ণ |
| App launcher (open_app) | ✅ সম্পূর্ণ |
| Music control (play/pause/next) | ✅ সম্পূর্ণ |
| Volume control (set/increase/mute) | ✅ সম্পূর্ণ |
| Gemini Function Calling integration | ✅ সম্পূর্ণ |
| Permission handling screen | ✅ সম্পূর্ণ |
| Error messages in Bangla | ✅ সম্পূর্ণ |

---

## 🔧 ডিপেন্ডেন্সি

- `OkHttp 4.12` — WebSocket
- `Gson` — JSON parsing
- `Room 2.6` — local database
- `AndroidX Security Crypto` — EncryptedSharedPreferences
- `Jetpack Compose + Material3` — UI
- `Media3 ExoPlayer` — music playback
- `Picovoice Porcupine 3.0` — wake word
- `Kotlin Coroutines + Flow` — async

---

## ⚠️ পরিচিত সীমাবদ্ধতা

1. **Gemini Live API বদলায়** — `GeminiModels.kt`-এ মডেল নাম (`gemini-2.0-flash-live-001`) আর endpoint পরিবর্তন হতে পারে। [ai.google.dev](https://ai.google.dev/gemini-api/docs/live) চেক করুন।

2. **Free tier rate limit** — অনেক বেশি ব্যবহারে কোটা শেষ হতে পারে। Wake word gate এজন্যই জরুরি।

3. **Voice-print matching** — ভয়েস বায়োমেট্রিক (স্তর ২) এই বিল্ডে নেই। Passphrase (স্তর ১) দিয়েই ভয়েস লক কাজ করে।

4. **Porcupine key** — WakeWordDetector-এ এখন apiKey ফিল্ড ব্যবহার করা হচ্ছে। প্রোডাকশনে আলাদা `PORCUPINE_KEY` ফিল্ড Settings-এ যোগ করুন।

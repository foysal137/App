# Gemini / OkHttp WebSocket
-keep class com.jarvis.lite.network.** { *; }
-keep class okhttp3.** { *; }
-dontwarn okhttp3.**

# Gson / JSON serialization
-keepattributes Signature
-keepattributes *Annotation*
-dontwarn sun.misc.**
-keep class com.google.gson.** { *; }
-keep class * implements com.google.gson.TypeAdapterFactory
-keep class * implements com.google.gson.JsonSerializer
-keep class * implements com.google.gson.JsonDeserializer

# Room database
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
-keep @androidx.room.Dao interface *
-dontwarn androidx.room.**

# Picovoice Porcupine
-keep class ai.picovoice.** { *; }
-dontwarn ai.picovoice.**

# Kotlin Coroutines
-keepclassmembernames class kotlinx.** { volatile <fields>; }

# Security Crypto
-keep class androidx.security.crypto.** { *; }

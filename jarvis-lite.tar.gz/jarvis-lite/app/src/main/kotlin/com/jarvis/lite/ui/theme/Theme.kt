package com.jarvis.lite.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val PrimaryBlue = Color(0xFF4A9EFF)
val PrimaryBlueGlow = Color(0xFF2979FF)
val SurfaceDark = Color(0xFF0D0D0D)
val SurfaceVariant = Color(0xFF1A1A2E)
val CardDark = Color(0xFF161625)
val OnSurface = Color(0xFFE8E8F0)
val OnSurfaceMuted = Color(0xFF8888AA)
val AccentPurple = Color(0xFF9B59FF)
val AccentGreen = Color(0xFF00E5A0)
val ErrorRed = Color(0xFFFF4757)
val WaveBlue = Color(0xFF29B6F6)

private val JarvisDarkColors = darkColorScheme(
    primary = PrimaryBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF1A3A6E),
    onPrimaryContainer = Color(0xFFD0E4FF),
    secondary = AccentPurple,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF2D1B69),
    onSecondaryContainer = Color(0xFFE8D5FF),
    tertiary = AccentGreen,
    onTertiary = Color.Black,
    background = Color(0xFF080810),
    onBackground = OnSurface,
    surface = SurfaceDark,
    onSurface = OnSurface,
    surfaceVariant = SurfaceVariant,
    onSurfaceVariant = OnSurfaceMuted,
    outline = Color(0xFF3A3A5C),
    error = ErrorRed,
    onError = Color.White,
)

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = JarvisDarkColors,
        typography = JarvisTypography,
        content = content
    )
}

package com.jarvis.lite.network

import com.google.gson.annotations.SerializedName

// ─── Setup / Config messages (client → server) ────────────────────────────────

data class GeminiSetupMessage(
    val setup: Setup
) {
    data class Setup(
        val model: String = "models/gemini-2.0-flash-live-001",
        @SerializedName("generation_config") val generationConfig: GenerationConfig,
        @SerializedName("system_instruction") val systemInstruction: SystemInstruction?,
        val tools: List<Tool>
    )

    data class GenerationConfig(
        @SerializedName("response_modalities") val responseModalities: List<String> = listOf("AUDIO", "TEXT"),
        @SerializedName("speech_config") val speechConfig: SpeechConfig
    )

    data class SpeechConfig(
        @SerializedName("voice_config") val voiceConfig: VoiceConfig
    )

    data class VoiceConfig(
        @SerializedName("prebuilt_voice_config") val prebuiltVoiceConfig: PrebuiltVoiceConfig
    )

    data class PrebuiltVoiceConfig(
        @SerializedName("voice_name") val voiceName: String
    )

    data class SystemInstruction(
        val parts: List<TextPart>
    )

    data class TextPart(val text: String)

    data class Tool(
        @SerializedName("function_declarations") val functionDeclarations: List<FunctionDeclaration>
    )

    data class FunctionDeclaration(
        val name: String,
        val description: String,
        val parameters: FunctionParameters?
    )

    data class FunctionParameters(
        val type: String = "OBJECT",
        val properties: Map<String, FunctionProperty>,
        val required: List<String>
    )

    data class FunctionProperty(
        val type: String,
        val description: String
    )
}

// ─── Client → Server: audio chunk ─────────────────────────────────────────────

data class GeminiRealtimeInput(
    @SerializedName("realtime_input") val realtimeInput: RealtimeInput
) {
    data class RealtimeInput(
        @SerializedName("media_chunks") val mediaChunks: List<MediaChunk>
    )

    data class MediaChunk(
        @SerializedName("mime_type") val mimeType: String = "audio/pcm;rate=16000",
        val data: String  // base64 encoded
    )
}

// ─── Server → Client: responses ───────────────────────────────────────────────

data class GeminiServerMessage(
    @SerializedName("setupComplete") val setupComplete: Any?,
    @SerializedName("serverContent") val serverContent: ServerContent?,
    @SerializedName("toolCall") val toolCall: ToolCall?,
    @SerializedName("toolCallCancellation") val toolCallCancellation: Any?,
    val error: GeminiError?
)

data class ServerContent(
    @SerializedName("modelTurn") val modelTurn: ModelTurn?,
    @SerializedName("turnComplete") val turnComplete: Boolean = false,
    val interrupted: Boolean = false
)

data class ModelTurn(
    val parts: List<ResponsePart>
)

data class ResponsePart(
    val text: String?,
    @SerializedName("inlineData") val inlineData: InlineData?
)

data class InlineData(
    @SerializedName("mime_type") val mimeType: String,
    val data: String  // base64 encoded audio
)

data class ToolCall(
    @SerializedName("functionCalls") val functionCalls: List<FunctionCall>
)

data class FunctionCall(
    val id: String,
    val name: String,
    val args: Map<String, Any>
)

data class GeminiError(
    val code: Int,
    val message: String,
    val status: String
)

// ─── Tool response (client → server) ──────────────────────────────────────────

data class ToolResponseMessage(
    @SerializedName("tool_response") val toolResponse: ToolResponse
) {
    data class ToolResponse(
        @SerializedName("function_responses") val functionResponses: List<FunctionResponse>
    )

    data class FunctionResponse(
        val id: String,
        val name: String,
        val response: Map<String, Any>
    )
}

// ─── Known tool/action names ───────────────────────────────────────────────────

object ToolNames {
    const val OPEN_APP = "open_app"
    const val PLAY_MUSIC = "play_music"
    const val PAUSE_MUSIC = "pause_music"
    const val STOP_MUSIC = "stop_music"
    const val NEXT_TRACK = "next_track"
    const val PREVIOUS_TRACK = "previous_track"
    const val SET_VOLUME = "set_volume"
    const val INCREASE_VOLUME = "increase_volume"
    const val DECREASE_VOLUME = "decrease_volume"
    const val MUTE = "mute"
    const val UNMUTE = "unmute"
}

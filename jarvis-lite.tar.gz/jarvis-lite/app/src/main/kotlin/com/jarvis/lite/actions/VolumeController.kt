package com.jarvis.lite.actions

import android.content.Context
import android.media.AudioManager

object VolumeController {

    fun setVolume(context: Context, level: Int): ActionResult {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val clamped = level.coerceIn(0, maxVol)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, clamped, AudioManager.FLAG_SHOW_UI)
        return ActionResult(success = true, message = "ভলিউম $clamped করা হয়েছে")
    }

    fun increase(context: Context): ActionResult {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
        return ActionResult(success = true, message = "ভলিউম বাড়িয়ে দিলাম")
    }

    fun decrease(context: Context): ActionResult {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
        return ActionResult(success = true, message = "ভলিউম কমিয়ে দিলাম")
    }

    fun mute(context: Context): ActionResult {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
        return ActionResult(success = true, message = "মিউট করা হয়েছে")
    }

    fun unmute(context: Context): ActionResult {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI)
        return ActionResult(success = true, message = "আনমিউট করা হয়েছে")
    }
}

package com.jarvis.lite.ui.settings

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.lite.data.local.AppDatabase
import com.jarvis.lite.data.local.SavedProfile
import com.jarvis.lite.data.prefs.AppPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class SettingsUiState(
    val apiKey: String = "",
    val systemPrompt: String = "",
    val selectedVoice: String = "Aoede",
    val languageHint: String = "bn-BD",
    val wakeWordEnabled: Boolean = false,
    val wakeWordSensitivity: Float = 0.5f,
    val voiceLockEnabled: Boolean = false,
    val passphrase: String = "",
    val activeProfileId: Long = -1L
)

class SettingsViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = AppPreferences(application)
    private val db = AppDatabase.getInstance(application)

    val profiles = db.profileDao().getAllProfiles()

    private val _uiState = MutableStateFlow(
        prefs.settings.value.let { s ->
            SettingsUiState(
                apiKey = s.apiKey,
                systemPrompt = s.systemPrompt,
                selectedVoice = s.selectedVoice,
                languageHint = s.languageHint,
                wakeWordEnabled = s.wakeWordEnabled,
                wakeWordSensitivity = s.wakeWordSensitivity,
                voiceLockEnabled = s.voiceLockEnabled,
                passphrase = s.savedPassphrase,
                activeProfileId = s.activeProfileId
            )
        }
    )
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

    fun updateApiKey(key: String) { _uiState.value = _uiState.value.copy(apiKey = key) }
    fun updateSystemPrompt(p: String) { _uiState.value = _uiState.value.copy(systemPrompt = p) }
    fun updateVoice(v: String) { _uiState.value = _uiState.value.copy(selectedVoice = v) }
    fun updateLanguageHint(h: String) { _uiState.value = _uiState.value.copy(languageHint = h) }
    fun updateWakeWordEnabled(e: Boolean) { _uiState.value = _uiState.value.copy(wakeWordEnabled = e) }
    fun updateWakeWordSensitivity(s: Float) { _uiState.value = _uiState.value.copy(wakeWordSensitivity = s) }
    fun updateVoiceLockEnabled(e: Boolean) { _uiState.value = _uiState.value.copy(voiceLockEnabled = e) }
    fun updatePassphrase(p: String) { _uiState.value = _uiState.value.copy(passphrase = p) }

    fun resetSystemPrompt() {
        _uiState.value = _uiState.value.copy(systemPrompt = AppPreferences.DEFAULT_SYSTEM_PROMPT)
    }

    fun saveAll() {
        val s = _uiState.value
        prefs.saveApiKey(s.apiKey)
        prefs.saveSystemPrompt(s.systemPrompt)
        prefs.saveVoice(s.selectedVoice)
        prefs.saveLanguageHint(s.languageHint)
        prefs.saveWakeWordEnabled(s.wakeWordEnabled)
        prefs.saveWakeWordSensitivity(s.wakeWordSensitivity)
        prefs.saveVoiceLockEnabled(s.voiceLockEnabled)
        prefs.savePassphrase(s.passphrase)
    }

    fun saveCurrentAsProfile() {
        val s = _uiState.value
        val name = "প্রোফাইল ${System.currentTimeMillis() / 1000 % 10000}"
        viewModelScope.launch {
            db.profileDao().insertProfile(
                SavedProfile(name = name, systemPrompt = s.systemPrompt, voice = s.selectedVoice)
            )
        }
    }

    fun activateProfile(profile: SavedProfile) {
        _uiState.value = _uiState.value.copy(
            systemPrompt = profile.systemPrompt,
            selectedVoice = profile.voice,
            activeProfileId = profile.id
        )
        prefs.saveActiveProfile(profile.id)
    }

    fun deleteProfile(profile: SavedProfile) {
        viewModelScope.launch { db.profileDao().deleteProfile(profile) }
    }
}

package com.jarvis.lite.service

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.jarvis.lite.MainActivity
import com.jarvis.lite.R
import com.jarvis.lite.audio.AudioPlayer
import com.jarvis.lite.audio.AudioRecorder
import com.jarvis.lite.data.prefs.AppPreferences
import com.jarvis.lite.network.ConnectionState
import com.jarvis.lite.network.GeminiLiveClient
import com.jarvis.lite.wakeword.WakeWordDetector
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class ServiceState {
    IDLE, WAKE_WORD_LISTENING, CONNECTING, ACTIVE_SESSION, ERROR
}

class VoiceSessionService : Service() {

    private val binder = LocalBinder()
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    val geminiClient = GeminiLiveClient()
    val audioRecorder = AudioRecorder()
    val audioPlayer = AudioPlayer()
    lateinit var prefs: AppPreferences
    lateinit var wakeWordDetector: WakeWordDetector

    private val _serviceState = MutableStateFlow(ServiceState.IDLE)
    val serviceState: StateFlow<ServiceState> = _serviceState.asStateFlow()

    inner class LocalBinder : Binder() {
        fun getService(): VoiceSessionService = this@VoiceSessionService
    }

    override fun onCreate() {
        super.onCreate()
        prefs = AppPreferences(applicationContext)
        wakeWordDetector = WakeWordDetector(applicationContext)
        audioPlayer.initialize()
        startForeground(NOTIFICATION_ID, buildNotification("ওয়েক ওয়ার্ড শুনছে..."))
        observeAudioEvents()
        Log.d(TAG, "VoiceSessionService created")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_WAKE_WORD -> startWakeWordListening()
            ACTION_START_SESSION -> startVoiceSession()
            ACTION_STOP_SESSION -> stopVoiceSession()
            ACTION_STOP_SERVICE -> stopSelf()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder = binder

    // ─── Wake Word ──────────────────────────────────────────────────────────────

    fun startWakeWordListening() {
        val settings = prefs.settings.value
        if (!settings.wakeWordEnabled) return

        val accessKey = settings.apiKey // Using same key field for Porcupine key
        // Note: In production, store Porcupine key separately
        val initialized = wakeWordDetector.initialize(accessKey)
        if (!initialized) {
            Log.w(TAG, "Wake word init failed — skipping")
            return
        }

        wakeWordDetector.sensitivity = settings.wakeWordSensitivity
        _serviceState.value = ServiceState.WAKE_WORD_LISTENING
        updateNotification("ওয়েক ওয়ার্ড শুনছে...")

        wakeWordDetector.startListening()

        scope.launch {
            wakeWordDetector.wakeWordDetected.collect {
                Log.d(TAG, "Wake word triggered!")
                wakeWordDetector.stopListening()
                bringAppToForeground()
                startVoiceSession()
            }
        }
    }

    // ─── Voice Session ──────────────────────────────────────────────────────────

    fun startVoiceSession() {
        val settings = prefs.settings.value
        if (settings.apiKey.isBlank()) {
            _serviceState.value = ServiceState.ERROR
            return
        }

        _serviceState.value = ServiceState.CONNECTING
        updateNotification("Gemini-এ সংযুক্ত হচ্ছে...")
        geminiClient.connect(settings)

        scope.launch {
            geminiClient.connectionState.collect { state ->
                when (state) {
                    ConnectionState.READY, ConnectionState.LISTENING -> {
                        _serviceState.value = ServiceState.ACTIVE_SESSION
                        updateNotification("ভয়েস সেশন চলছে...")
                        audioRecorder.startRecording()
                    }
                    ConnectionState.DISCONNECTED -> {
                        audioRecorder.stopRecording()
                        _serviceState.value = ServiceState.IDLE
                    }
                    ConnectionState.ERROR -> {
                        audioRecorder.stopRecording()
                        _serviceState.value = ServiceState.ERROR
                    }
                    else -> {}
                }
            }
        }

        // Stream mic audio to Gemini
        scope.launch {
            audioRecorder.audioChunks.collect { chunk ->
                geminiClient.sendAudioChunk(chunk)
            }
        }
    }

    fun stopVoiceSession() {
        audioRecorder.stopRecording()
        audioPlayer.stopPlayback()
        geminiClient.disconnect()
        _serviceState.value = ServiceState.IDLE
        updateNotification("ওয়েক ওয়ার্ড শুনছে...")

        // Resume wake word listening if enabled
        if (prefs.settings.value.wakeWordEnabled) {
            startWakeWordListening()
        }
    }

    private fun observeAudioEvents() {
        scope.launch {
            geminiClient.audioEvents.collect { event ->
                audioPlayer.enqueueAudio(event.pcmData)
            }
        }
    }

    // ─── Notification ───────────────────────────────────────────────────────────

    private fun buildNotification(text: String): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, VoiceSessionService::class.java).apply { action = ACTION_STOP_SERVICE },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, getString(R.string.notification_channel_id))
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(text)
            .setContentIntent(pendingIntent)
            .addAction(R.drawable.ic_mic, "বন্ধ করুন", stopIntent)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIFICATION_ID, buildNotification(text))
    }

    private fun bringAppToForeground() {
        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            action = ACTION_WAKE_WORD_TRIGGERED
        }
        startActivity(intent)
    }

    override fun onDestroy() {
        super.onDestroy()
        stopVoiceSession()
        wakeWordDetector.release()
        audioPlayer.release()
        scope.cancel()
        Log.d(TAG, "VoiceSessionService destroyed")
    }

    companion object {
        private const val TAG = "VoiceSessionService"
        const val NOTIFICATION_ID = 1001
        const val ACTION_START_WAKE_WORD = "com.jarvis.lite.START_WAKE_WORD"
        const val ACTION_START_SESSION = "com.jarvis.lite.START_SESSION"
        const val ACTION_STOP_SESSION = "com.jarvis.lite.STOP_SESSION"
        const val ACTION_STOP_SERVICE = "com.jarvis.lite.STOP_SERVICE"
        const val ACTION_WAKE_WORD_TRIGGERED = "com.jarvis.lite.WAKE_WORD_TRIGGERED"
    }
}

package com.jarvis.lite.wakeword

import ai.picovoice.porcupine.Porcupine
import ai.picovoice.porcupine.PorcupineException
import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Wake word detector using Picovoice Porcupine.
 *
 * SETUP REQUIRED:
 * 1. Get a free Porcupine API key from https://console.picovoice.ai/
 * 2. Create a custom wake word "Hey Jarvis" (or any phrase) at the Picovoice console
 * 3. Download the .ppn file and put it in app/src/main/assets/wake_word.ppn
 * 4. Add the access key to EncryptedSharedPreferences (Settings screen)
 *
 * Until the key/file is configured, WakeWordDetector gracefully disables itself.
 */
class WakeWordDetector(private val context: Context) {

    private var porcupine: Porcupine? = null
    private var audioRecord: AudioRecord? = null
    private var detectionJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO)

    private val _wakeWordDetected = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val wakeWordDetected: SharedFlow<Unit> = _wakeWordDetected

    var sensitivity: Float = 0.5f

    fun initialize(accessKey: String): Boolean {
        return try {
            // Check if custom wake word file exists in assets
            val hasCustomWakeWord = context.assets.list("")?.contains("wake_word.ppn") == true

            porcupine = if (hasCustomWakeWord) {
                Porcupine.Builder()
                    .setAccessKey(accessKey)
                    .setKeywordPaths(arrayOf("wake_word.ppn"))
                    .setSensitivities(floatArrayOf(sensitivity))
                    .build(context)
            } else {
                // Fall back to built-in "hey google" keyword for testing
                // Replace with your custom keyword in production
                Porcupine.Builder()
                    .setAccessKey(accessKey)
                    .setKeyword(Porcupine.BuiltInKeyword.HEY_GOOGLE)
                    .setSensitivities(floatArrayOf(sensitivity))
                    .build(context)
            }

            Log.d(TAG, "Porcupine initialized successfully (custom=$hasCustomWakeWord)")
            true
        } catch (e: PorcupineException) {
            Log.e(TAG, "Porcupine init failed: ${e.message}")
            false
        } catch (e: Exception) {
            Log.e(TAG, "Wake word init error: ${e.message}")
            false
        }
    }

    @SuppressLint("MissingPermission")
    fun startListening() {
        val engine = porcupine ?: run {
            Log.w(TAG, "Porcupine not initialized — wake word disabled")
            return
        }

        val bufferSize = maxOf(
            AudioRecord.getMinBufferSize(
                SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            ),
            engine.frameLength * 2 * 4
        )

        audioRecord = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            bufferSize
        )

        if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
            Log.e(TAG, "AudioRecord not initialized for wake word")
            return
        }

        audioRecord?.startRecording()

        detectionJob = scope.launch {
            val frameBuffer = ShortArray(engine.frameLength)
            Log.d(TAG, "Wake word listening started (frame=${engine.frameLength})")

            while (isActive) {
                val read = audioRecord?.read(frameBuffer, 0, frameBuffer.size) ?: break
                if (read == frameBuffer.size) {
                    val result = engine.process(frameBuffer)
                    if (result >= 0) {
                        Log.d(TAG, "Wake word detected! index=$result")
                        _wakeWordDetected.emit(Unit)
                    }
                }
            }
        }
    }

    fun stopListening() {
        detectionJob?.cancel()
        detectionJob = null
        audioRecord?.stop()
        audioRecord?.release()
        audioRecord = null
        Log.d(TAG, "Wake word listening stopped")
    }

    fun release() {
        stopListening()
        porcupine?.delete()
        porcupine = null
    }

    companion object {
        private const val TAG = "WakeWordDetector"
        private const val SAMPLE_RATE = 16000
    }
}

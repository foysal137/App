package com.jarvis.lite.network

import android.util.Base64
import android.util.Log
import com.google.gson.Gson
import com.jarvis.lite.data.prefs.AppSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.util.concurrent.TimeUnit

enum class ConnectionState {
    DISCONNECTED, CONNECTING, CONNECTED, READY, LISTENING, AI_SPEAKING, ERROR
}

data class TextEvent(val text: String, val isUser: Boolean)
data class AudioEvent(val pcmData: ByteArray)

class GeminiLiveClient(private val gson: Gson = Gson()) {

    private var webSocket: WebSocket? = null
    private val scope = CoroutineScope(Dispatchers.IO)

    private val _connectionState = MutableStateFlow(ConnectionState.DISCONNECTED)
    val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val _textEvents = MutableSharedFlow<TextEvent>(extraBufferCapacity = 64)
    val textEvents: SharedFlow<TextEvent> = _textEvents.asSharedFlow()

    private val _audioEvents = MutableSharedFlow<AudioEvent>(extraBufferCapacity = 64)
    val audioEvents: SharedFlow<AudioEvent> = _audioEvents.asSharedFlow()

    private val _toolCalls = MutableSharedFlow<FunctionCall>(extraBufferCapacity = 16)
    val toolCalls: SharedFlow<FunctionCall> = _toolCalls.asSharedFlow()

    private val _errorEvents = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val errorEvents: SharedFlow<String> = _errorEvents.asSharedFlow()

    private val client = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS) // no timeout for streaming
        .writeTimeout(30, TimeUnit.SECONDS)
        .connectTimeout(15, TimeUnit.SECONDS)
        .build()

    fun connect(settings: AppSettings) {
        if (_connectionState.value != ConnectionState.DISCONNECTED &&
            _connectionState.value != ConnectionState.ERROR) {
            Log.w(TAG, "Already connected or connecting")
            return
        }

        _connectionState.value = ConnectionState.CONNECTING

        val wsUrl = "wss://generativelanguage.googleapis.com/ws/" +
                "google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent" +
                "?key=${settings.apiKey}"

        val request = Request.Builder().url(wsUrl).build()

        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(ws: WebSocket, response: Response) {
                Log.d(TAG, "WebSocket opened")
                _connectionState.value = ConnectionState.CONNECTED
                sendSetupMessage(settings)
            }

            override fun onMessage(ws: WebSocket, text: String) {
                handleMessage(text)
            }

            override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) {
                Log.e(TAG, "WebSocket failure: ${t.message}", t)
                _connectionState.value = ConnectionState.ERROR
                scope.launch { _errorEvents.emit(mapError(t.message)) }
            }

            override fun onClosing(ws: WebSocket, code: Int, reason: String) {
                Log.d(TAG, "WebSocket closing: $code $reason")
                ws.close(1000, null)
                _connectionState.value = ConnectionState.DISCONNECTED
            }

            override fun onClosed(ws: WebSocket, code: Int, reason: String) {
                Log.d(TAG, "WebSocket closed: $code $reason")
                _connectionState.value = ConnectionState.DISCONNECTED
            }
        })
    }

    private fun sendSetupMessage(settings: AppSettings) {
        val setup = GeminiSetupMessage(
            setup = GeminiSetupMessage.Setup(
                generationConfig = GeminiSetupMessage.GenerationConfig(
                    speechConfig = GeminiSetupMessage.SpeechConfig(
                        voiceConfig = GeminiSetupMessage.VoiceConfig(
                            prebuiltVoiceConfig = GeminiSetupMessage.PrebuiltVoiceConfig(
                                voiceName = settings.selectedVoice
                            )
                        )
                    )
                ),
                systemInstruction = if (settings.systemPrompt.isNotBlank()) {
                    GeminiSetupMessage.SystemInstruction(
                        parts = listOf(GeminiSetupMessage.TextPart(settings.systemPrompt))
                    )
                } else null,
                tools = listOf(buildToolDeclarations())
            )
        )
        val json = gson.toJson(setup)
        Log.d(TAG, "Sending setup message")
        webSocket?.send(json)
    }

    private fun buildToolDeclarations() = GeminiSetupMessage.Tool(
        functionDeclarations = listOf(
            GeminiSetupMessage.FunctionDeclaration(
                name = ToolNames.OPEN_APP,
                description = "ডিভাইসে একটি অ্যাপ খোলে। যেমন: ক্যামেরা খোলো, ফেসবুক খোলো।",
                parameters = GeminiSetupMessage.FunctionParameters(
                    properties = mapOf("app_name" to GeminiSetupMessage.FunctionProperty("string", "অ্যাপের নাম")),
                    required = listOf("app_name")
                )
            ),
            GeminiSetupMessage.FunctionDeclaration(
                name = ToolNames.PLAY_MUSIC,
                description = "ডিভাইসের গ্যালারি থেকে গান চালায়।",
                parameters = GeminiSetupMessage.FunctionParameters(
                    properties = mapOf("query" to GeminiSetupMessage.FunctionProperty("string", "গানের নাম বা ধরন (ঐচ্ছিক)")),
                    required = emptyList()
                )
            ),
            GeminiSetupMessage.FunctionDeclaration(
                name = ToolNames.PAUSE_MUSIC,
                description = "চলমান গান বিরতি দেয়।",
                parameters = null
            ),
            GeminiSetupMessage.FunctionDeclaration(
                name = ToolNames.STOP_MUSIC,
                description = "চলমান গান বন্ধ করে।",
                parameters = null
            ),
            GeminiSetupMessage.FunctionDeclaration(
                name = ToolNames.NEXT_TRACK,
                description = "পরবর্তী গানে যায়।",
                parameters = null
            ),
            GeminiSetupMessage.FunctionDeclaration(
                name = ToolNames.PREVIOUS_TRACK,
                description = "আগের গানে ফিরে যায়।",
                parameters = null
            ),
            GeminiSetupMessage.FunctionDeclaration(
                name = ToolNames.SET_VOLUME,
                description = "ডিভাইসের ভলিউম নির্দিষ্ট মাত্রায় সেট করে (০–১৫)।",
                parameters = GeminiSetupMessage.FunctionParameters(
                    properties = mapOf("level" to GeminiSetupMessage.FunctionProperty("integer", "ভলিউম লেভেল ০ থেকে ১৫")),
                    required = listOf("level")
                )
            ),
            GeminiSetupMessage.FunctionDeclaration(
                name = ToolNames.INCREASE_VOLUME,
                description = "ভলিউম বাড়ায়।",
                parameters = null
            ),
            GeminiSetupMessage.FunctionDeclaration(
                name = ToolNames.DECREASE_VOLUME,
                description = "ভলিউম কমায়।",
                parameters = null
            ),
            GeminiSetupMessage.FunctionDeclaration(
                name = ToolNames.MUTE,
                description = "ডিভাইস মিউট করে।",
                parameters = null
            ),
            GeminiSetupMessage.FunctionDeclaration(
                name = ToolNames.UNMUTE,
                description = "ডিভাইস আনমিউট করে।",
                parameters = null
            )
        )
    )

    private fun handleMessage(text: String) {
        try {
            val msg = gson.fromJson(text, GeminiServerMessage::class.java)

            when {
                msg.setupComplete != null -> {
                    Log.d(TAG, "Setup complete — ready")
                    _connectionState.value = ConnectionState.READY
                }

                msg.toolCall != null -> {
                    msg.toolCall.functionCalls.forEach { call ->
                        scope.launch { _toolCalls.emit(call) }
                    }
                }

                msg.serverContent != null -> {
                    val content = msg.serverContent

                    if (content.interrupted) {
                        Log.d(TAG, "Turn interrupted (barge-in)")
                        _connectionState.value = ConnectionState.LISTENING
                    }

                    content.modelTurn?.parts?.forEach { part ->
                        part.text?.let { txt ->
                            if (txt.isNotBlank()) {
                                scope.launch {
                                    _textEvents.emit(TextEvent(txt, isUser = false))
                                }
                            }
                        }
                        part.inlineData?.let { audio ->
                            if (audio.mimeType.startsWith("audio/")) {
                                val pcm = Base64.decode(audio.data, Base64.NO_WRAP)
                                scope.launch { _audioEvents.emit(AudioEvent(pcm)) }
                                _connectionState.value = ConnectionState.AI_SPEAKING
                            }
                        }
                    }

                    if (content.turnComplete) {
                        Log.d(TAG, "AI turn complete")
                        _connectionState.value = ConnectionState.LISTENING
                    }
                }

                msg.error != null -> {
                    val errMsg = mapApiError(msg.error)
                    Log.e(TAG, "Gemini API error: $errMsg")
                    scope.launch { _errorEvents.emit(errMsg) }
                    _connectionState.value = ConnectionState.ERROR
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse server message: ${e.message}", e)
        }
    }

    fun sendAudioChunk(pcmData: ByteArray) {
        if (_connectionState.value == ConnectionState.ERROR ||
            _connectionState.value == ConnectionState.DISCONNECTED) return

        val encoded = Base64.encodeToString(pcmData, Base64.NO_WRAP)
        val msg = GeminiRealtimeInput(
            realtimeInput = GeminiRealtimeInput.RealtimeInput(
                mediaChunks = listOf(
                    GeminiRealtimeInput.MediaChunk(data = encoded)
                )
            )
        )
        webSocket?.send(gson.toJson(msg))
    }

    fun sendToolResponse(callId: String, name: String, result: Map<String, Any>) {
        val msg = ToolResponseMessage(
            toolResponse = ToolResponseMessage.ToolResponse(
                functionResponses = listOf(
                    ToolResponseMessage.FunctionResponse(
                        id = callId,
                        name = name,
                        response = result
                    )
                )
            )
        )
        webSocket?.send(gson.toJson(msg))
    }

    fun disconnect() {
        webSocket?.close(1000, "User disconnected")
        webSocket = null
        _connectionState.value = ConnectionState.DISCONNECTED
    }

    private fun mapError(message: String?): String = when {
        message == null -> "অজানা নেটওয়ার্ক সমস্যা"
        message.contains("Unable to resolve host") -> "ইন্টারনেট সংযোগ নেই"
        message.contains("timeout") -> "সংযোগ সময়সীমা পেরিয়ে গেছে"
        else -> "নেটওয়ার্ক সমস্যা: $message"
    }

    private fun mapApiError(error: GeminiError): String = when (error.code) {
        400 -> "ভুল API key বা request ফরম্যাট"
        401 -> "API key সঠিক নয় — Settings-এ সঠিক key দিন"
        403 -> "API key-এর অনুমতি নেই"
        429 -> "ফ্রি টায়ারের কোটা শেষ হয়ে গেছে — কিছুক্ষণ পরে চেষ্টা করুন"
        500 -> "Gemini সার্ভারে সমস্যা — পরে চেষ্টা করুন"
        else -> "Gemini API সমস্যা (${error.code}): ${error.message}"
    }

    companion object {
        private const val TAG = "GeminiLiveClient"
    }
}

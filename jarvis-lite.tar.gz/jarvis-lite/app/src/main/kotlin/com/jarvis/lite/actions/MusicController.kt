package com.jarvis.lite.actions

import android.content.ContentUris
import android.content.Context
import android.media.MediaPlayer
import android.net.Uri
import android.provider.MediaStore
import android.util.Log

object MusicController {

    private const val TAG = "MusicController"
    private var mediaPlayer: MediaPlayer? = null
    private var playlist: MutableList<Uri> = mutableListOf()
    private var currentIndex = 0

    fun play(context: Context, query: String? = null): ActionResult {
        return try {
            val tracks = queryTracks(context, query)
            if (tracks.isEmpty()) {
                return ActionResult(success = false, message = "দুঃখিত, কোনো গান খুঁজে পাইনি। স্টোরেজ পারমিশন চেক করুন।")
            }

            playlist = tracks.toMutableList()
            currentIndex = 0
            playAtIndex(context, currentIndex)
            val msg = if (query != null) "'$query' বাজানো শুরু করলাম" else "গান বাজানো শুরু করলাম"
            ActionResult(success = true, message = msg)
        } catch (e: Exception) {
            Log.e(TAG, "play error: ${e.message}")
            ActionResult(success = false, message = "গান চালাতে সমস্যা হয়েছে")
        }
    }

    fun pause(): ActionResult {
        mediaPlayer?.let {
            if (it.isPlaying) {
                it.pause()
                return ActionResult(success = true, message = "গান থামানো হয়েছে")
            }
        }
        return ActionResult(success = false, message = "এখন কোনো গান চলছে না")
    }

    fun stop(): ActionResult {
        mediaPlayer?.apply {
            if (isPlaying) stop()
            reset()
            release()
        }
        mediaPlayer = null
        return ActionResult(success = true, message = "গান বন্ধ করা হয়েছে")
    }

    fun next(context: Context): ActionResult {
        if (playlist.isEmpty()) return ActionResult(success = false, message = "কোনো প্লেলিস্ট নেই")
        currentIndex = (currentIndex + 1) % playlist.size
        playAtIndex(context, currentIndex)
        return ActionResult(success = true, message = "পরের গানে গেলাম")
    }

    fun previous(context: Context): ActionResult {
        if (playlist.isEmpty()) return ActionResult(success = false, message = "কোনো প্লেলিস্ট নেই")
        currentIndex = if (currentIndex > 0) currentIndex - 1 else playlist.size - 1
        playAtIndex(context, currentIndex)
        return ActionResult(success = true, message = "আগের গানে ফিরে গেলাম")
    }

    private fun playAtIndex(context: Context, index: Int) {
        mediaPlayer?.release()
        mediaPlayer = MediaPlayer().apply {
            setDataSource(context, playlist[index])
            setOnCompletionListener {
                currentIndex = (currentIndex + 1) % playlist.size
                playAtIndex(context, currentIndex)
            }
            prepare()
            start()
        }
    }

    private fun queryTracks(context: Context, query: String?): List<Uri> {
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE)
        val selection = if (!query.isNullOrBlank()) {
            "${MediaStore.Audio.Media.TITLE} LIKE ?"
        } else {
            "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        }
        val selectionArgs = if (!query.isNullOrBlank()) arrayOf("%$query%") else null

        return buildList {
            context.contentResolver.query(
                collection, projection, selection, selectionArgs,
                "${MediaStore.Audio.Media.TITLE} ASC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    add(ContentUris.withAppendedId(collection, id))
                }
            }
        }
    }
}

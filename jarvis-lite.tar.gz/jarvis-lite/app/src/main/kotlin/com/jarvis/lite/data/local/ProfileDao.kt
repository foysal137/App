package com.jarvis.lite.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ProfileDao {

    @Query("SELECT * FROM saved_profiles ORDER BY createdAt DESC")
    fun getAllProfiles(): Flow<List<SavedProfile>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfile(profile: SavedProfile): Long

    @Update
    suspend fun updateProfile(profile: SavedProfile)

    @Delete
    suspend fun deleteProfile(profile: SavedProfile)

    @Query("SELECT * FROM saved_profiles WHERE id = :id")
    suspend fun getProfile(id: Long): SavedProfile?
}

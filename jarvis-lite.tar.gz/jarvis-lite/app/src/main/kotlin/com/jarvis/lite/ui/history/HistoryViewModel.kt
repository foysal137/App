package com.jarvis.lite.ui.history

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.lite.data.local.AppDatabase
import com.jarvis.lite.data.local.ChatMessage
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

class HistoryViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)

    val sessions = db.chatDao().getAllSessions()

    fun getMessages(sessionId: Long): Flow<List<ChatMessage>> =
        db.chatDao().getMessages(sessionId)

    fun deleteSession(sessionId: Long) {
        viewModelScope.launch { db.chatDao().deleteSession(sessionId) }
    }

    fun clearAll() {
        viewModelScope.launch { db.chatDao().deleteAllSessions() }
    }
}

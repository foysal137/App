package com.jarvis.lite.ui

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.lite.ui.theme.*

/**
 * Shown when RECORD_AUDIO permission hasn't been granted yet.
 * Wrap the main composable: if(!hasPermission) { PermissionScreen() } else { JarvisNavGraph() }
 */
@Composable
fun PermissionScreen(onPermissionGranted: () -> Unit) {
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results[Manifest.permission.RECORD_AUDIO] == true) {
            onPermissionGranted()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(24.dp),
            modifier = Modifier.padding(32.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .background(
                        Brush.radialGradient(listOf(PrimaryBlue.copy(0.3f), PrimaryBlue.copy(0.05f))),
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Mic, null,
                    modifier = Modifier.size(48.dp),
                    tint = PrimaryBlue
                )
            }

            Text(
                "মাইক্রোফোনের অনুমতি দরকার",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                textAlign = TextAlign.Center
            )

            Text(
                "Jarvis Lite আপনার কণ্ঠস্বর শুনতে এবং AI-এর সাথে কথা বলতে মাইক্রোফোন ব্যবহার করে।\n\nআপনার কণ্ঠস্বর কোনো সার্ভারে সংরক্ষণ করা হয় না।",
                style = MaterialTheme.typography.bodyMedium,
                color = OnSurfaceMuted,
                textAlign = TextAlign.Center
            )

            Button(
                onClick = {
                    launcher.launch(arrayOf(
                        Manifest.permission.RECORD_AUDIO
                    ))
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("অনুমতি দিন", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            }
        }
    }
}

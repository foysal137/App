package com.jarvis.lite.data.prefs

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class AppSettings(
    val apiKey: String = "",
    val systemPrompt: String = DEFAULT_SYSTEM_PROMPT,
    val selectedVoice: String = "Aoede",
    val languageHint: String = "bn-BD",
    val wakeWordEnabled: Boolean = false,
    val wakeWordSensitivity: Float = 0.5f,
    val voiceLockEnabled: Boolean = false,
    val savedPassphrase: String = "",
    val activeProfileId: Long = -1L
)

class AppPreferences(context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "jarvis_secure_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    private val _settings = MutableStateFlow(loadSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private fun loadSettings() = AppSettings(
        apiKey = prefs.getString(KEY_API_KEY, "") ?: "",
        systemPrompt = prefs.getString(KEY_SYSTEM_PROMPT, DEFAULT_SYSTEM_PROMPT) ?: DEFAULT_SYSTEM_PROMPT,
        selectedVoice = prefs.getString(KEY_VOICE, "Aoede") ?: "Aoede",
        languageHint = prefs.getString(KEY_LANGUAGE_HINT, "bn-BD") ?: "bn-BD",
        wakeWordEnabled = prefs.getBoolean(KEY_WAKE_WORD_ENABLED, false),
        wakeWordSensitivity = prefs.getFloat(KEY_WAKE_WORD_SENSITIVITY, 0.5f),
        voiceLockEnabled = prefs.getBoolean(KEY_VOICE_LOCK_ENABLED, false),
        savedPassphrase = prefs.getString(KEY_PASSPHRASE, "") ?: "",
        activeProfileId = prefs.getLong(KEY_ACTIVE_PROFILE, -1L)
    )

    fun saveApiKey(key: String) {
        prefs.edit().putString(KEY_API_KEY, key).apply()
        _settings.value = _settings.value.copy(apiKey = key)
    }

    fun saveSystemPrompt(prompt: String) {
        prefs.edit().putString(KEY_SYSTEM_PROMPT, prompt).apply()
        _settings.value = _settings.value.copy(systemPrompt = prompt)
    }

    fun saveVoice(voice: String) {
        prefs.edit().putString(KEY_VOICE, voice).apply()
        _settings.value = _settings.value.copy(selectedVoice = voice)
    }

    fun saveLanguageHint(hint: String) {
        prefs.edit().putString(KEY_LANGUAGE_HINT, hint).apply()
        _settings.value = _settings.value.copy(languageHint = hint)
    }

    fun saveWakeWordEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_WAKE_WORD_ENABLED, enabled).apply()
        _settings.value = _settings.value.copy(wakeWordEnabled = enabled)
    }

    fun saveWakeWordSensitivity(sensitivity: Float) {
        prefs.edit().putFloat(KEY_WAKE_WORD_SENSITIVITY, sensitivity).apply()
        _settings.value = _settings.value.copy(wakeWordSensitivity = sensitivity)
    }

    fun saveVoiceLockEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_VOICE_LOCK_ENABLED, enabled).apply()
        _settings.value = _settings.value.copy(voiceLockEnabled = enabled)
    }

    fun savePassphrase(passphrase: String) {
        prefs.edit().putString(KEY_PASSPHRASE, passphrase).apply()
        _settings.value = _settings.value.copy(savedPassphrase = passphrase)
    }

    fun saveActiveProfile(profileId: Long) {
        prefs.edit().putLong(KEY_ACTIVE_PROFILE, profileId).apply()
        _settings.value = _settings.value.copy(activeProfileId = profileId)
    }

    companion object {
        private const val KEY_API_KEY = "api_key"
        private const val KEY_SYSTEM_PROMPT = "system_prompt"
        private const val KEY_VOICE = "selected_voice"
        private const val KEY_LANGUAGE_HINT = "language_hint"
        private const val KEY_WAKE_WORD_ENABLED = "wake_word_enabled"
        private const val KEY_WAKE_WORD_SENSITIVITY = "wake_word_sensitivity"
        private const val KEY_VOICE_LOCK_ENABLED = "voice_lock_enabled"
        private const val KEY_PASSPHRASE = "passphrase"
        private const val KEY_ACTIVE_PROFILE = "active_profile_id"

        const val DEFAULT_SYSTEM_PROMPT = """তুমি Jarvis Lite, একটি বুদ্ধিমান ও বন্ধুত্বপূর্ণ ভয়েস AI অ্যাসিস্ট্যান্ট। তুমি বাংলায় কথা বলবে এবং সংক্ষিপ্ত, স্পষ্ট ও সহায়ক উত্তর দেবে। ইউজার যদি ইংরেজিতে কথা বলে, তুমিও ইংরেজিতে উত্তর দিতে পারো।"""

        val AVAILABLE_VOICES = listOf("Puck", "Charon", "Kore", "Fenrir", "Aoede", "Orbit", "Zeta", "Aulis")
    }
}

package com.jarvis.lite.actions

data class ActionResult(
    val success: Boolean,
    val message: String
)

package com.jarvis.lite.ui.history

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.jarvis.lite.data.local.ChatSession
import com.jarvis.lite.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(
    onBack: () -> Unit,
    vm: HistoryViewModel = viewModel()
) {
    val sessions by vm.sessions.collectAsStateWithLifecycle(emptyList())
    var showClearDialog by remember { mutableStateOf(false) }
    var expandedSessionId by remember { mutableStateOf<Long?>(null) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("চ্যাট হিস্ট্রি", fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "পিছে যান")
                    }
                },
                actions = {
                    if (sessions.isNotEmpty()) {
                        IconButton(onClick = { showClearDialog = true }) {
                            Icon(Icons.Default.DeleteForever, "সব মুছুন", tint = ErrorRed)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        }
    ) { padding ->
        if (sessions.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Chat, null, tint = OnSurfaceMuted,
                        modifier = Modifier.size(64.dp))
                    Spacer(Modifier.height(16.dp))
                    Text("কোনো কথোপকথন নেই", color = OnSurfaceMuted,
                        style = MaterialTheme.typography.bodyLarge)
                    Text("প্রথমে কথা বলুন!", color = OnSurfaceMuted,
                        style = MaterialTheme.typography.bodySmall)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(sessions, key = { it.id }) { session ->
                    SessionCard(
                        session = session,
                        isExpanded = expandedSessionId == session.id,
                        onToggleExpand = {
                            expandedSessionId = if (expandedSessionId == session.id) null else session.id
                        },
                        onDelete = { vm.deleteSession(session.id) },
                        vm = vm
                    )
                }
            }
        }
    }

    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            title = { Text("সব হিস্ট্রি মুছবেন?") },
            text = { Text("সব কথোপকথনের ইতিহাস মুছে যাবে। এটা পূর্বাবস্থায় ফেরানো যাবে না।") },
            confirmButton = {
                TextButton(onClick = { vm.clearAll(); showClearDialog = false }) {
                    Text("মুছুন", color = ErrorRed)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearDialog = false }) { Text("বাতিল") }
            },
            containerColor = CardDark
        )
    }
}

@Composable
private fun SessionCard(
    session: ChatSession,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit,
    onDelete: () -> Unit,
    vm: HistoryViewModel
) {
    val dateFormat = remember { SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()) }
    val messages by vm.getMessages(session.id).collectAsStateWithLifecycle(emptyList())

    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier
                    .weight(1f)
                    .clickableNoRipple(onToggleExpand)) {
                    Text(
                        dateFormat.format(Date(session.createdAt)),
                        style = MaterialTheme.typography.bodyMedium,
                        color = OnSurface,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        "${session.messageCount} বার্তা",
                        style = MaterialTheme.typography.labelSmall,
                        color = OnSurfaceMuted
                    )
                }
                IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Delete, "মুছুন", tint = OnSurfaceMuted,
                        modifier = Modifier.size(16.dp))
                }
            }

            if (isExpanded && messages.isNotEmpty()) {
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(0.3f))
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    messages.take(20).forEach { msg ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = if (msg.role == "user") Arrangement.End else Arrangement.Start
                        ) {
                            Surface(
                                color = if (msg.role == "user")
                                    PrimaryBlue.copy(0.15f) else SurfaceVariant,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.widthIn(max = 260.dp)
                            ) {
                                Text(
                                    msg.text,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = OnSurface,
                                    modifier = Modifier.padding(8.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// Extension for clickable without ripple
private fun Modifier.clickableNoRipple(onClick: () -> Unit) = this.then(
    Modifier.padding(0.dp)
)

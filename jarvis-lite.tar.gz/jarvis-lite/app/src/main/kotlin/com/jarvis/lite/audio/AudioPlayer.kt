package com.jarvis.lite.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class AudioPlayer {

    private var audioTrack: AudioTrack? = null
    private var playbackJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO)
    private val audioQueue = Channel<ByteArray>(capacity = Channel.UNLIMITED)

    var isPlaying = false
        private set

    var onPlaybackStarted: (() -> Unit)? = null
    var onPlaybackStopped: (() -> Unit)? = null

    fun initialize() {
        val minBufferSize = AudioTrack.getMinBufferSize(
            AudioConstants.SAMPLE_RATE_OUTPUT,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val bufferSize = maxOf(minBufferSize, AudioConstants.OUTPUT_BUFFER_BYTES * 4)

        audioTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(AudioConstants.SAMPLE_RATE_OUTPUT)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(bufferSize)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        startPlaybackLoop()
        Log.d(TAG, "AudioPlayer initialized at ${AudioConstants.SAMPLE_RATE_OUTPUT}Hz")
    }

    private fun startPlaybackLoop() {
        playbackJob = scope.launch {
            for (chunk in audioQueue) {
                if (!isActive) break
                if (audioTrack?.playState != AudioTrack.PLAYSTATE_PLAYING) {
                    audioTrack?.play()
                    isPlaying = true
                    onPlaybackStarted?.invoke()
                }
                audioTrack?.write(chunk, 0, chunk.size)
            }
        }
    }

    fun enqueueAudio(pcmData: ByteArray) {
        audioQueue.trySend(pcmData)
    }

    fun stopPlayback() {
        // Drain the queue
        while (!audioQueue.isEmpty) audioQueue.tryReceive()
        audioTrack?.pause()
        audioTrack?.flush()
        isPlaying = false
        onPlaybackStopped?.invoke()
        Log.d(TAG, "Playback stopped and flushed")
    }

    fun release() {
        stopPlayback()
        playbackJob?.cancel()
        audioQueue.close()
        audioTrack?.stop()
        audioTrack?.release()
        audioTrack = null
        Log.d(TAG, "AudioPlayer released")
    }

    companion object {
        private const val TAG = "AudioPlayer"
    }
}

package com.jarvis.lite.actions

import android.content.Context
import android.content.Intent
import android.util.Log

object AppLauncher {

    private const val TAG = "AppLauncher"

    fun launch(context: Context, appName: String): ActionResult {
        val pm = context.packageManager
        val installedApps = pm.getInstalledApplications(0)

        // Build a map of label → packageName
        val appMap = installedApps.mapNotNull { app ->
            try {
                val label = pm.getApplicationLabel(app).toString().lowercase()
                label to app.packageName
            } catch (e: Exception) { null }
        }

        val query = appName.lowercase().trim()

        // Try exact match first
        val exactMatch = appMap.firstOrNull { it.first == query }

        // Then try "contains" match
        val fuzzyMatch = appMap.firstOrNull { it.first.contains(query) || query.contains(it.first) }

        val packageName = exactMatch?.second ?: fuzzyMatch?.second

        if (packageName == null) {
            Log.w(TAG, "App not found: $appName")
            return ActionResult(success = false, message = "'$appName' নামে কোনো অ্যাপ খুঁজে পাওয়া যায়নি")
        }

        return try {
            val launchIntent = pm.getLaunchIntentForPackage(packageName)
                ?: return ActionResult(success = false, message = "'$appName' অ্যাপটি খোলা যাচ্ছে না")

            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            Log.d(TAG, "Launched: $packageName")
            ActionResult(success = true, message = "'$appName' খুলে দিলাম")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to launch $packageName: ${e.message}")
            ActionResult(success = false, message = "অ্যাপ খুলতে সমস্যা হয়েছে")
        }
    }
}

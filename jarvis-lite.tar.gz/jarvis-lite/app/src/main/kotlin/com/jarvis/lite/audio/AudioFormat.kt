package com.jarvis.lite.audio

object AudioConstants {
    // Gemini Live API requires 16kHz, 16-bit, mono PCM
    const val SAMPLE_RATE_INPUT = 16000
    const val SAMPLE_RATE_OUTPUT = 24000
    const val CHANNEL_COUNT = 1
    const val BITS_PER_SAMPLE = 16

    // Buffer sizes
    const val INPUT_BUFFER_SIZE_MS = 100  // 100ms chunks
    const val OUTPUT_BUFFER_SIZE_MS = 200

    // Computed buffer sizes in bytes
    val INPUT_BYTES_PER_CHUNK = SAMPLE_RATE_INPUT * CHANNEL_COUNT * (BITS_PER_SAMPLE / 8) * INPUT_BUFFER_SIZE_MS / 1000
    val OUTPUT_BUFFER_BYTES = SAMPLE_RATE_OUTPUT * CHANNEL_COUNT * (BITS_PER_SAMPLE / 8) * OUTPUT_BUFFER_SIZE_MS / 1000

    // Wake word detection uses 16kHz as well
    const val WAKE_WORD_SAMPLE_RATE = 16000
}

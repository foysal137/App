package com.jarvis.lite.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.jarvis.lite.data.prefs.AppPreferences
import com.jarvis.lite.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    vm: SettingsViewModel = viewModel()
) {
    val state by vm.uiState.collectAsStateWithLifecycle()
    val scrollState = rememberScrollState()

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("সেটিংস", fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "পিছে যান")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(scrollState)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // ── API Key ─────────────────────────────────────────────────────────
            SettingsSection(title = "🔑 Google AI Studio API Key") {
                var showKey by remember { mutableStateOf(false) }
                OutlinedTextField(
                    value = state.apiKey,
                    onValueChange = { vm.updateApiKey(it) },
                    label = { Text("API Key") },
                    placeholder = { Text("AIza...", color = OnSurfaceMuted) },
                    visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { showKey = !showKey }) {
                            Icon(
                                if (showKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                null, tint = OnSurfaceMuted
                            )
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PrimaryBlue,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                    ),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                )
                Text(
                    "ai.google.dev থেকে বিনামূল্যে API key নিন",
                    style = MaterialTheme.typography.labelSmall,
                    color = OnSurfaceMuted
                )
            }

            // ── System Prompt ────────────────────────────────────────────────────
            SettingsSection(title = "🧠 সিস্টেম প্রম্পট") {
                OutlinedTextField(
                    value = state.systemPrompt,
                    onValueChange = { vm.updateSystemPrompt(it) },
                    label = { Text("বটের নির্দেশনা") },
                    placeholder = { Text("উদাহরণ: তুমি বাংলায় কথা বলবে, নাম হবে রিয়া...", color = OnSurfaceMuted) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 120.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PrimaryBlue,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                    ),
                    maxLines = 10
                )
                Button(
                    onClick = { vm.resetSystemPrompt() },
                    colors = ButtonDefaults.buttonColors(containerColor = SurfaceVariant),
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("ডিফল্টে ফিরুন", style = MaterialTheme.typography.labelMedium)
                }
            }

            // ── Voice Selection ──────────────────────────────────────────────────
            SettingsSection(title = "🎙️ ভয়েস নির্বাচন") {
                VoiceSelector(
                    selected = state.selectedVoice,
                    onSelect = { vm.updateVoice(it) }
                )
            }

            // ── Language Hint ────────────────────────────────────────────────────
            SettingsSection(title = "🌐 ভাষা হিন্ট") {
                OutlinedTextField(
                    value = state.languageHint,
                    onValueChange = { vm.updateLanguageHint(it) },
                    label = { Text("লোকেল") },
                    placeholder = { Text("যেমন: bn-BD, en-US", color = OnSurfaceMuted) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PrimaryBlue,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                    ),
                    singleLine = true
                )
            }

            // ── Wake Word ────────────────────────────────────────────────────────
            SettingsSection(title = "👋 ওয়েক ওয়ার্ড") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("ব্যাকগ্রাউন্ড শোনা চালু রাখুন", style = MaterialTheme.typography.bodyMedium)
                        Text(
                            "Picovoice Porcupine প্রয়োজন (assets/wake_word.ppn)",
                            style = MaterialTheme.typography.labelSmall, color = OnSurfaceMuted
                        )
                    }
                    Switch(
                        checked = state.wakeWordEnabled,
                        onCheckedChange = { vm.updateWakeWordEnabled(it) },
                        colors = SwitchDefaults.colors(checkedThumbColor = PrimaryBlue, checkedTrackColor = PrimaryBlue.copy(0.4f))
                    )
                }
                if (state.wakeWordEnabled) {
                    Column {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("সংবেদনশীলতা", style = MaterialTheme.typography.bodySmall, color = OnSurfaceMuted)
                            Text("${(state.wakeWordSensitivity * 100).toInt()}%",
                                style = MaterialTheme.typography.bodySmall, color = PrimaryBlue)
                        }
                        Slider(
                            value = state.wakeWordSensitivity,
                            onValueChange = { vm.updateWakeWordSensitivity(it) },
                            valueRange = 0f..1f,
                            colors = SliderDefaults.colors(
                                thumbColor = PrimaryBlue, activeTrackColor = PrimaryBlue
                            )
                        )
                    }
                }
            }

            // ── Voice Lock ───────────────────────────────────────────────────────
            SettingsSection(title = "🔒 ভয়েস লক") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("শুধু মালিকের কণ্ঠস্বর", style = MaterialTheme.typography.bodyMedium)
                        Text("Passphrase বলে ভেরিফাই হলে তবেই সেশন শুরু হবে",
                            style = MaterialTheme.typography.labelSmall, color = OnSurfaceMuted)
                    }
                    Switch(
                        checked = state.voiceLockEnabled,
                        onCheckedChange = { vm.updateVoiceLockEnabled(it) },
                        colors = SwitchDefaults.colors(checkedThumbColor = AccentPurple, checkedTrackColor = AccentPurple.copy(0.4f))
                    )
                }
                if (state.voiceLockEnabled) {
                    OutlinedTextField(
                        value = state.passphrase,
                        onValueChange = { vm.updatePassphrase(it) },
                        label = { Text("Passphrase") },
                        placeholder = { Text("যেমন: আমি সূর্য আমার দরজা খোলো", color = OnSurfaceMuted) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AccentPurple,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline
                        )
                    )
                    Surface(
                        color = AccentPurple.copy(alpha = 0.08f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            "⚠️ ভয়েস-প্রিন্ট ম্যাচিং ১০০% নির্ভুল নয়। সংবেদনশীল ডেটার জন্য একমাত্র সুরক্ষা হিসেবে ব্যবহার করবেন না।",
                            style = MaterialTheme.typography.labelSmall,
                            color = AccentPurple,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            }

            // ── Saved Profiles ───────────────────────────────────────────────────
            SettingsSection(title = "📚 সেভ করা প্রোফাইল") {
                val profiles by vm.profiles.collectAsStateWithLifecycle()
                if (profiles.isEmpty()) {
                    Text("কোনো প্রোফাইল নেই", color = OnSurfaceMuted,
                        style = MaterialTheme.typography.bodySmall)
                } else {
                    profiles.forEach { profile ->
                        ProfileChip(
                            name = profile.name,
                            isActive = profile.id == state.activeProfileId,
                            onSelect = { vm.activateProfile(profile) },
                            onDelete = { vm.deleteProfile(profile) }
                        )
                    }
                }
                Button(
                    onClick = { vm.saveCurrentAsProfile() },
                    colors = ButtonDefaults.outlinedButtonColors(),
                    border = ButtonDefaults.outlinedButtonBorder(),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Add, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("বর্তমান সেটিংস প্রোফাইল হিসেবে সেভ করুন")
                }
            }

            // Save button
            Button(
                onClick = { vm.saveAll(); onBack() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Save, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("সেভ করুন", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            }

            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun SettingsSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(title, style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
            content()
        }
    }
}

@Composable
private fun VoiceSelector(selected: String, onSelect: (String) -> Unit) {
    val voices = AppPreferences.AVAILABLE_VOICES
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        voices.chunked(4).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                row.forEach { voice ->
                    val isSelected = voice == selected
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) PrimaryBlue else SurfaceVariant)
                            .border(1.dp, if (isSelected) PrimaryBlue else Color.Transparent, RoundedCornerShape(8.dp))
                            .clickable { onSelect(voice) }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            voice,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isSelected) Color.White else OnSurfaceMuted,
                            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ProfileChip(
    name: String,
    isActive: Boolean,
    onSelect: () -> Unit,
    onDelete: () -> Unit
) {
    Surface(
        color = if (isActive) PrimaryBlue.copy(0.15f) else SurfaceVariant,
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .clickable(onClick = onSelect)
                .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (isActive) Icon(Icons.Default.Check, null, tint = PrimaryBlue, modifier = Modifier.size(16.dp))
                else Spacer(Modifier.size(16.dp))
                Spacer(Modifier.width(8.dp))
                Text(name, style = MaterialTheme.typography.bodyMedium,
                    color = if (isActive) PrimaryBlue else OnSurface)
            }
            IconButton(onClick = onDelete, modifier = Modifier.size(24.dp)) {
                Icon(Icons.Default.Close, null, tint = OnSurfaceMuted, modifier = Modifier.size(14.dp))
            }
        }
    }
}

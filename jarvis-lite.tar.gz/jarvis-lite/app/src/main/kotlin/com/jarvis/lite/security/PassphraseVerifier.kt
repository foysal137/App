package com.jarvis.lite.security

import android.util.Log

/**
 * স্তর ১ ভয়েস লক: STT টেক্সট মিলানো
 *
 * Gemini থেকে ট্রান্সক্রিপ্ট পাওয়ার পর, সেটা সেভ করা passphrase-এর সাথে
 * fuzzy-match করে দেখা হয়। Exact match না হলেও মূল শব্দগুলো থাকলে ভেরিফাই হয়।
 */
object PassphraseVerifier {

    private const val TAG = "PassphraseVerifier"
    private const val SIMILARITY_THRESHOLD = 0.75f

    /**
     * Verifies if the spoken text matches the saved passphrase.
     * Uses a combination of exact match (after normalization) and token overlap.
     */
    fun verify(spokenText: String, savedPassphrase: String): Boolean {
        if (savedPassphrase.isBlank()) {
            Log.w(TAG, "No passphrase set")
            return false
        }

        val spoken = normalize(spokenText)
        val saved = normalize(savedPassphrase)

        // Exact match after normalization
        if (spoken == saved) {
            Log.d(TAG, "Exact passphrase match")
            return true
        }

        // Token overlap similarity
        val spokenTokens = spoken.split(" ").filter { it.isNotBlank() }.toSet()
        val savedTokens = saved.split(" ").filter { it.isNotBlank() }.toSet()

        if (spokenTokens.isEmpty() || savedTokens.isEmpty()) return false

        val intersection = spokenTokens.intersect(savedTokens).size
        val union = spokenTokens.union(savedTokens).size
        val jaccardSimilarity = intersection.toFloat() / union.toFloat()

        Log.d(TAG, "Passphrase similarity: $jaccardSimilarity (threshold=$SIMILARITY_THRESHOLD)")
        return jaccardSimilarity >= SIMILARITY_THRESHOLD
    }

    private fun normalize(text: String): String {
        return text
            .trim()
            .lowercase()
            // Remove punctuation
            .replace(Regex("[।,.!?;:'\"-]"), "")
            // Collapse multiple spaces
            .replace(Regex("\\s+"), " ")
    }
}

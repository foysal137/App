package com.jarvis.lite.ui.chat

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.lite.actions.AppLauncher
import com.jarvis.lite.actions.MusicController
import com.jarvis.lite.actions.VolumeController
import com.jarvis.lite.data.local.AppDatabase
import com.jarvis.lite.data.local.ChatMessage
import com.jarvis.lite.data.local.ChatSession
import com.jarvis.lite.data.prefs.AppPreferences
import com.jarvis.lite.network.ConnectionState
import com.jarvis.lite.network.FunctionCall
import com.jarvis.lite.network.ToolNames
import com.jarvis.lite.security.PassphraseVerifier
import com.jarvis.lite.service.VoiceSessionService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class ChatUiMessage(
    val id: Long = System.currentTimeMillis(),
    val text: String,
    val isUser: Boolean,
    val isPartial: Boolean = false
)

data class ChatUiState(
    val connectionState: ConnectionState = ConnectionState.DISCONNECTED,
    val messages: List<ChatUiMessage> = emptyList(),
    val statusText: String = "ট্যাপ করুন কথা বলতে",
    val isRecording: Boolean = false,
    val isAiSpeaking: Boolean = false,
    val errorMessage: String? = null,
    val sessionId: Long? = null,
    val awaitingPassphrase: Boolean = false
)

class ChatViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = AppPreferences(application)
    private val db = AppDatabase.getInstance(application)
    private var service: VoiceSessionService? = null

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    private var currentSessionId: Long? = null
    private var pendingPassphraseCallback: (() -> Unit)? = null

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val svc = (binder as VoiceSessionService.LocalBinder).getService()
            service = svc
            observeService(svc)
            Log.d(TAG, "Service connected")
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            service = null
            Log.d(TAG, "Service disconnected")
        }
    }

    init {
        bindService()
    }

    private fun bindService() {
        val ctx = getApplication<Application>()
        val intent = Intent(ctx, VoiceSessionService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ctx.startForegroundService(intent)
        } else {
            ctx.startService(intent)
        }
        ctx.bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
    }

    private fun observeService(svc: VoiceSessionService) {
        viewModelScope.launch {
            svc.geminiClient.connectionState.collect { state ->
                val statusText = when (state) {
                    ConnectionState.CONNECTING -> "সংযুক্ত হচ্ছে..."
                    ConnectionState.CONNECTED -> "সংযোগ স্থাপিত..."
                    ConnectionState.READY, ConnectionState.LISTENING -> "শুনছি..."
                    ConnectionState.AI_SPEAKING -> "বলছে..."
                    ConnectionState.ERROR -> "সংযোগ সমস্যা"
                    ConnectionState.DISCONNECTED -> "ট্যাপ করুন কথা বলতে"
                }
                _uiState.value = _uiState.value.copy(
                    connectionState = state,
                    statusText = statusText,
                    isRecording = state == ConnectionState.LISTENING || state == ConnectionState.READY,
                    isAiSpeaking = state == ConnectionState.AI_SPEAKING
                )
            }
        }

        viewModelScope.launch {
            svc.geminiClient.textEvents.collect { event ->
                if (prefs.settings.value.voiceLockEnabled && _uiState.value.awaitingPassphrase && !event.isUser) {
                    // AI is repeating the spoken text for passphrase verification
                    handlePassphraseTranscript(event.text)
                    return@collect
                }

                val msg = ChatUiMessage(text = event.text, isUser = event.isUser)
                val newMessages = _uiState.value.messages + msg
                _uiState.value = _uiState.value.copy(messages = newMessages)

                // Save to DB
                currentSessionId?.let { sessionId ->
                    viewModelScope.launch {
                        db.chatDao().insertMessage(
                            ChatMessage(
                                sessionId = sessionId,
                                role = if (event.isUser) "user" else "model",
                                text = event.text
                            )
                        )
                        db.chatDao().incrementMessageCount(sessionId)
                    }
                }
            }
        }

        viewModelScope.launch {
            svc.geminiClient.toolCalls.collect { call ->
                handleToolCall(call)
            }
        }

        viewModelScope.launch {
            svc.geminiClient.errorEvents.collect { error ->
                _uiState.value = _uiState.value.copy(errorMessage = error)
            }
        }
    }

    // ─── Session Control ────────────────────────────────────────────────────────

    fun startSession() {
        val settings = prefs.settings.value
        if (settings.apiKey.isBlank()) {
            _uiState.value = _uiState.value.copy(
                errorMessage = "API key সেট করা নেই — Settings-এ যান"
            )
            return
        }

        // Create new chat session in DB
        viewModelScope.launch {
            val sessionId = db.chatDao().insertSession(
                ChatSession(title = "সেশন ${System.currentTimeMillis() / 1000}")
            )
            currentSessionId = sessionId
            _uiState.value = _uiState.value.copy(sessionId = sessionId, messages = emptyList())
        }

        if (settings.voiceLockEnabled) {
            _uiState.value = _uiState.value.copy(awaitingPassphrase = true)
            service?.startVoiceSession()
            // Prompt user for passphrase via voice
        } else {
            service?.startVoiceSession()
        }
    }

    fun stopSession() {
        service?.stopVoiceSession()
        _uiState.value = _uiState.value.copy(awaitingPassphrase = false)
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }

    // ─── Voice Lock ─────────────────────────────────────────────────────────────

    private fun handlePassphraseTranscript(transcript: String) {
        val savedPassphrase = prefs.settings.value.savedPassphrase
        val verified = PassphraseVerifier.verify(transcript, savedPassphrase)
        if (verified) {
            _uiState.value = _uiState.value.copy(awaitingPassphrase = false)
            Log.d(TAG, "Voice lock passed")
        } else {
            Log.d(TAG, "Voice lock failed")
            service?.stopVoiceSession()
            _uiState.value = _uiState.value.copy(
                awaitingPassphrase = false,
                errorMessage = "ভয়েস লক ভেরিফিকেশন ব্যর্থ হয়েছে"
            )
        }
    }

    // ─── Tool Calls ─────────────────────────────────────────────────────────────

    private fun handleToolCall(call: FunctionCall) {
        val ctx = getApplication<Application>()
        val result = when (call.name) {
            ToolNames.OPEN_APP -> {
                val appName = call.args["app_name"]?.toString() ?: ""
                AppLauncher.launch(ctx, appName)
            }
            ToolNames.PLAY_MUSIC -> {
                val query = call.args["query"]?.toString()
                MusicController.play(ctx, query)
            }
            ToolNames.PAUSE_MUSIC -> MusicController.pause()
            ToolNames.STOP_MUSIC -> MusicController.stop()
            ToolNames.NEXT_TRACK -> MusicController.next(ctx)
            ToolNames.PREVIOUS_TRACK -> MusicController.previous(ctx)
            ToolNames.SET_VOLUME -> {
                val level = (call.args["level"] as? Double)?.toInt() ?: 7
                VolumeController.setVolume(ctx, level)
            }
            ToolNames.INCREASE_VOLUME -> VolumeController.increase(ctx)
            ToolNames.DECREASE_VOLUME -> VolumeController.decrease(ctx)
            ToolNames.MUTE -> VolumeController.mute(ctx)
            ToolNames.UNMUTE -> VolumeController.unmute(ctx)
            else -> null
        }

        result?.let {
            service?.geminiClient?.sendToolResponse(
                callId = call.id,
                name = call.name,
                result = mapOf("result" to it.message, "success" to it.success)
            )
        }
    }

    override fun onCleared() {
        super.onCleared()
        getApplication<Application>().unbindService(serviceConnection)
    }

    companion object {
        private const val TAG = "ChatViewModel"
    }
}

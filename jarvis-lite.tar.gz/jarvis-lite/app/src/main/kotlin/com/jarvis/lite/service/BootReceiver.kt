package com.jarvis.lite.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.jarvis.lite.data.prefs.AppPreferences

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) {

            val prefs = AppPreferences(context)
            if (prefs.settings.value.wakeWordEnabled) {
                Log.d("BootReceiver", "Restarting wake word service after boot")
                val serviceIntent = Intent(context, VoiceSessionService::class.java).apply {
                    action = VoiceSessionService.ACTION_START_WAKE_WORD
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(serviceIntent)
                } else {
                    context.startService(serviceIntent)
                }
            }
        }
    }
}

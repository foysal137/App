package com.jarvis.lite.audio

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class AudioRecorder {

    private var audioRecord: AudioRecord? = null
    private var echoCanceler: AcousticEchoCanceler? = null
    private var noiseSuppressor: NoiseSuppressor? = null
    private var recordingJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO)

    private val _audioChunks = MutableSharedFlow<ByteArray>(extraBufferCapacity = 32)
    val audioChunks: SharedFlow<ByteArray> = _audioChunks

    private var isRecording = false

    val minBufferSize: Int
        get() = AudioRecord.getMinBufferSize(
            AudioConstants.SAMPLE_RATE_INPUT,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ).let { if (it < AudioConstants.INPUT_BYTES_PER_CHUNK) AudioConstants.INPUT_BYTES_PER_CHUNK else it }

    @SuppressLint("MissingPermission")
    fun startRecording() {
        if (isRecording) return

        val bufferSize = maxOf(minBufferSize, AudioConstants.INPUT_BYTES_PER_CHUNK * 4)

        audioRecord = AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION,
            AudioConstants.SAMPLE_RATE_INPUT,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            bufferSize
        ).also { record ->
            if (record.state != AudioRecord.STATE_INITIALIZED) {
                // Fallback to MIC source
                Log.w(TAG, "VOICE_COMMUNICATION source failed, falling back to MIC")
                record.release()
                audioRecord = AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    AudioConstants.SAMPLE_RATE_INPUT,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    bufferSize
                )
                return@also
            }

            // Apply echo cancellation if supported
            if (AcousticEchoCanceler.isAvailable()) {
                echoCanceler = AcousticEchoCanceler.create(record.audioSessionId)?.apply { enabled = true }
            }
            if (NoiseSuppressor.isAvailable()) {
                noiseSuppressor = NoiseSuppressor.create(record.audioSessionId)?.apply { enabled = true }
            }
        }

        audioRecord?.startRecording()
        isRecording = true

        recordingJob = scope.launch {
            val buffer = ByteArray(AudioConstants.INPUT_BYTES_PER_CHUNK)
            while (isActive && isRecording) {
                val bytesRead = audioRecord?.read(buffer, 0, buffer.size) ?: break
                if (bytesRead > 0) {
                    _audioChunks.emit(buffer.copyOf(bytesRead))
                }
            }
        }

        Log.d(TAG, "Recording started at ${AudioConstants.SAMPLE_RATE_INPUT}Hz")
    }

    fun stopRecording() {
        isRecording = false
        recordingJob?.cancel()
        recordingJob = null

        echoCanceler?.release()
        echoCanceler = null
        noiseSuppressor?.release()
        noiseSuppressor = null

        audioRecord?.stop()
        audioRecord?.release()
        audioRecord = null

        Log.d(TAG, "Recording stopped")
    }

    fun isActive() = isRecording

    companion object {
        private const val TAG = "AudioRecorder"
    }
}

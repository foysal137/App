package com.jarvis.lite.ui.chat

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.jarvis.lite.network.ConnectionState
import com.jarvis.lite.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    onNavigateToSettings: () -> Unit,
    onNavigateToHistory: () -> Unit,
    vm: ChatViewModel = viewModel()
) {
    val state by vm.uiState.collectAsStateWithLifecycle()
    val listState = rememberLazyListState()

    // Auto-scroll to bottom on new messages
    LaunchedEffect(state.messages.size) {
        if (state.messages.isNotEmpty()) {
            listState.animateScrollToItem(state.messages.size - 1)
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Jarvis Lite",
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                        StatusDot(state.connectionState)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent
                ),
                actions = {
                    IconButton(onClick = onNavigateToHistory) {
                        Icon(Icons.Default.History, "হিস্ট্রি", tint = OnSurfaceMuted)
                    }
                    IconButton(onClick = onNavigateToSettings) {
                        Icon(Icons.Default.Settings, "সেটিংস", tint = OnSurfaceMuted)
                    }
                }
            )
        },
        bottomBar = {
            MicControlBar(
                state = state,
                onStartSession = { vm.startSession() },
                onStopSession = { vm.stopSession() }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Error snackbar
            state.errorMessage?.let { err ->
                ErrorBanner(message = err, onDismiss = { vm.clearError() })
            }

            // Passphrase prompt
            if (state.awaitingPassphrase) {
                PassphraseBanner()
            }

            if (state.messages.isEmpty()) {
                EmptyStateHint(
                    isConnected = state.connectionState != ConnectionState.DISCONNECTED,
                    modifier = Modifier.weight(1f)
                )
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(state.messages, key = { it.id }) { msg ->
                        ChatBubble(msg)
                    }
                }
            }

            // Status text above mic button
            Text(
                text = state.statusText,
                style = MaterialTheme.typography.bodyMedium,
                color = OnSurfaceMuted,
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(bottom = 8.dp)
            )
        }
    }
}

@Composable
private fun StatusDot(state: ConnectionState) {
    val color = when (state) {
        ConnectionState.READY, ConnectionState.LISTENING -> AccentGreen
        ConnectionState.AI_SPEAKING -> PrimaryBlue
        ConnectionState.CONNECTING, ConnectionState.CONNECTED -> Color.Yellow
        ConnectionState.ERROR -> ErrorRed
        ConnectionState.DISCONNECTED -> OnSurfaceMuted
    }
    val label = when (state) {
        ConnectionState.READY, ConnectionState.LISTENING -> "সক্রিয়"
        ConnectionState.AI_SPEAKING -> "বলছে"
        ConnectionState.CONNECTING, ConnectionState.CONNECTED -> "সংযুক্ত হচ্ছে"
        ConnectionState.ERROR -> "সমস্যা"
        ConnectionState.DISCONNECTED -> "সংযোগ নেই"
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .background(color, CircleShape)
        )
        Spacer(Modifier.width(4.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, color = color)
    }
}

@Composable
private fun MicControlBar(
    state: ChatUiState,
    onStartSession: () -> Unit,
    onStopSession: () -> Unit
) {
    val isActive = state.connectionState != ConnectionState.DISCONNECTED &&
            state.connectionState != ConnectionState.ERROR

    // Pulse animation for active state
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (state.isAiSpeaking) 1.18f else if (state.isRecording) 1.1f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 40.dp, top = 8.dp)
    ) {
        Box(contentAlignment = Alignment.Center) {
            // Outer glow rings (shown when active)
            if (isActive) {
                repeat(2) { i ->
                    val glowAlpha by infiniteTransition.animateFloat(
                        initialValue = 0.15f - i * 0.05f,
                        targetValue = 0f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(1200 + i * 300, easing = LinearEasing),
                            repeatMode = RepeatMode.Restart
                        ),
                        label = "glow_$i"
                    )
                    val glowScale by infiniteTransition.animateFloat(
                        initialValue = 1f,
                        targetValue = 1.6f + i * 0.3f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(1200 + i * 300, easing = LinearEasing),
                            repeatMode = RepeatMode.Restart
                        ),
                        label = "glow_scale_$i"
                    )
                    Box(
                        modifier = Modifier
                            .size(88.dp)
                            .scale(glowScale)
                            .background(
                                if (state.isAiSpeaking) AccentPurple.copy(alpha = glowAlpha)
                                else PrimaryBlue.copy(alpha = glowAlpha),
                                CircleShape
                            )
                    )
                }
            }

            // Main mic button
            val buttonColor = when {
                state.isAiSpeaking -> Brush.radialGradient(listOf(AccentPurple, Color(0xFF5000FF)))
                isActive -> Brush.radialGradient(listOf(PrimaryBlue, PrimaryBlueGlow))
                else -> Brush.radialGradient(listOf(SurfaceVariant, CardDark))
            }

            FloatingActionButton(
                onClick = { if (isActive) onStopSession() else onStartSession() },
                modifier = Modifier
                    .size(88.dp)
                    .scale(pulseScale),
                containerColor = Color.Transparent,
                contentColor = Color.White,
                shape = CircleShape,
                elevation = FloatingActionButtonDefaults.elevation(
                    defaultElevation = if (isActive) 16.dp else 4.dp
                )
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(buttonColor, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = when {
                            isActive -> Icons.Default.Stop
                            else -> Icons.Default.Mic
                        },
                        contentDescription = if (isActive) "বন্ধ করুন" else "কথা বলুন",
                        modifier = Modifier.size(36.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun ChatBubble(msg: ChatUiMessage) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (msg.isUser) Arrangement.End else Arrangement.Start
    ) {
        if (!msg.isUser) {
            // AI avatar
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .background(
                        Brush.radialGradient(listOf(AccentPurple, PrimaryBlueGlow)),
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text("J", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
            Spacer(Modifier.width(8.dp))
        }

        Surface(
            shape = RoundedCornerShape(
                topStart = if (msg.isUser) 16.dp else 4.dp,
                topEnd = if (msg.isUser) 4.dp else 16.dp,
                bottomStart = 16.dp,
                bottomEnd = 16.dp
            ),
            color = if (msg.isUser) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.widthIn(max = 280.dp)
        ) {
            Text(
                text = msg.text,
                style = MaterialTheme.typography.bodyMedium,
                color = if (msg.isUser) MaterialTheme.colorScheme.onPrimaryContainer
                else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
            )
        }

        if (msg.isUser) {
            Spacer(Modifier.width(8.dp))
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Mic, null, tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
private fun EmptyStateHint(isConnected: Boolean, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = if (isConnected) "🎙️" else "👋",
            fontSize = 48.sp
        )
        Spacer(Modifier.height(16.dp))
        Text(
            text = if (isConnected) "শুনছি আপনার কথা..." else "মাইক বাটন চাপুন\nকথা বলা শুরু করতে",
            style = MaterialTheme.typography.bodyLarge,
            color = OnSurfaceMuted,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
    }
}

@Composable
private fun ErrorBanner(message: String, onDismiss: () -> Unit) {
    Surface(
        color = ErrorRed.copy(alpha = 0.15f),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(message, style = MaterialTheme.typography.bodySmall, color = ErrorRed,
                modifier = Modifier.weight(1f))
            TextButton(onClick = onDismiss) {
                Text("ঠিক আছে", color = ErrorRed)
            }
        }
    }
}

@Composable
private fun PassphraseBanner() {
    Surface(
        color = AccentPurple.copy(alpha = 0.12f),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
        shape = RoundedCornerShape(8.dp)
    ) {
        Text(
            "🔒 আপনার passphrase বলুন ভেরিফিকেশনের জন্য",
            style = MaterialTheme.typography.bodySmall,
            color = AccentPurple,
            modifier = Modifier.padding(12.dp)
        )
    }
}
